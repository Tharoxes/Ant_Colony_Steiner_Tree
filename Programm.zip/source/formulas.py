#!/usr/bin/env python
# -*- coding: utf-8 -*-

import numpy as np
import matplotlib.pyplot as plt
import heapq
import math


def generate_ants():
    pass

def calculate_pheromones():
    pass